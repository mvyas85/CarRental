package edu.mrv.carrental.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.mrv.carrental.controllers.HomeController;
import edu.mrv.carrental.dao.CarDao;
import edu.mrv.carrental.dao.OrderDao;
import edu.mrv.carrental.domain.Car;
import edu.mrv.carrental.domain.Order;

@Service
public class OrderServiceImpl  implements OrderService {
	@Autowired
	@Qualifier("OrderDaoJdbcImpl")
	private OrderDao orderDao;

	@Override
	public void confirmOrder(Order order) {
		orderDao.insertOrder(order);
	}
	
}
