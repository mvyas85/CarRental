package edu.mrv.carrental.controllers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.mrv.carrental.domain.Car;
import edu.mrv.carrental.domain.Customer;
import edu.mrv.carrental.domain.Order;
import edu.mrv.carrental.services.CarService;
import edu.mrv.carrental.services.CustomerService;
import edu.mrv.carrental.services.OrderService;

@Controller
public class OrderController {
	@Autowired
	CustomerService customerService;
	@Autowired
	OrderService orderService;
	@Autowired
	CarService carService;
		
	///////////Process customer order and save it in databaSE////////////////////////
	@RequestMapping(value = "/processNewOrder", method = RequestMethod.POST)
	public ModelAndView processOrder( @RequestParam (value = "vehical_class") String vehical_class,
			@RequestParam (value = "StartDate") String StartDate,
			@RequestParam (value = "EndDate") String EndDate,
			@RequestParam (value = "carID") int carID, 
			@RequestParam (value = "totalDays") int totalDays,
			@RequestParam (value = "rateApplied")double rateApplied,
			@RequestParam (value = "amount") double amount,
			@RequestParam (value="tax") double tax,
			@RequestParam (value= "total") double total,HttpServletRequest request, HttpSession session) 
	{
		ModelAndView modelView;
		
		Customer customer = (Customer) session.getAttribute("customer");
		if(customer==null)
		{
			modelView = new ModelAndView("./loginPage");
			return modelView;
		}
		Car car = carService.viewACar(carID);
		
		DateFormat formatter, FORMATTER;
 		formatter = new SimpleDateFormat("yyyy-mm-dd'T'HH:mm:ss");
 		String oldStartDate = StartDate+":00";
 		String oldEndDate = EndDate+":00";
 		System.out.println("Old Start DAte is :: "+oldStartDate+"::End here ");
 		Date StartDate_ =null,EndDate_= null;
		try {
				StartDate_ = formatter.parse(oldStartDate.substring(0,19));
				EndDate_ = formatter.parse(oldEndDate.substring(0,19));
				System.out.println("trying to parse !!");
		 		
	 		} catch (ParseException e) {
			e.printStackTrace();
		}

		System.out.println("trying to NOT parse !!");
		FORMATTER = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
		StartDate = FORMATTER.format(StartDate_);
		EndDate = FORMATTER.format(EndDate_);
		Order order = new Order(0,customer.getCustomerID(),car.getCarID()
 				,totalDays,StartDate,EndDate,rateApplied,amount,tax,total);
		orderService.confirmOrder(order);
		modelView = new ModelAndView("./home");
		String success = "Order Placed Sucessfully";
		modelView.addObject("messege",success);
		
		return modelView;
	}	


}
