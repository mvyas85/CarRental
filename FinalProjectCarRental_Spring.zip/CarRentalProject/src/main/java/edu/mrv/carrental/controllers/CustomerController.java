package edu.mrv.carrental.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.mrv.carrental.domain.*;
import edu.mrv.carrental.services.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	//////////////////////////////INSERT///////////////////////////////
	///////////INSERT Customer Page/////////////////////////
	
	@RequestMapping(value = "/customer/insertNewCustomerDataForm", method = RequestMethod.POST)
	public ModelAndView newCustomerDataForm() {
		ModelAndView modelView;
		
 		modelView = new ModelAndView("customer/insertNewCustomerDataForm");
 		modelView.addObject("customer", new Customer());
		return modelView;
	}
	///////////INSERT Customer Success Page/////////////////////////
	@RequestMapping(value = "/customer/processNewCustomerProfile", method = RequestMethod.POST)
	public ModelAndView processNewCustomerForm(@Valid Customer customer, BindingResult result, HttpSession session) 
	{
		ModelAndView modelView;
		
		if (result.hasErrors()) {
			modelView = new ModelAndView("customer/insertNewCustomerDataForm", "customer", customer);
			System.out.println(customer);
			System.out.println(result.getAllErrors());
			return modelView;
		}
		session.setAttribute("customer", customer);
		
		customerService.addNewCustomer(customer);
		
 		modelView = new ModelAndView("customer/insertNewCustomerProfileSuccess");
 		modelView.addObject("customer",customer);
		
		return modelView;
	}
	//////////////////////////////DELETE///////////////////////////////
	///////////DELETE Customer Page to get ID/////////////////////////
	@RequestMapping(value = "/customer/removeCustomerDataPage", method = RequestMethod.GET)
	public ModelAndView removeCustomerPage( HttpSession session) {
		ModelAndView modelView;
		Customer customer  = (Customer) session.getAttribute("customer");
		
 		modelView = new ModelAndView("customer/deleteCustomerDataPage");
 		modelView.addObject("customer", customer);
		return modelView;
	}
	///////////DELETE Customer and Displays sucess/////////////////////////
	@RequestMapping(value = "/customer/removeCustomerByID", method = RequestMethod.GET)
	public ModelAndView removeCustomerByID(@RequestParam (value = "customerID") String customerID, HttpServletRequest request, HttpSession session) 
	{
		int id = Integer.parseInt(customerID);
		System.out.println(""+customerID);
		customerService.removeCustomer(id);
		ModelAndView modelView = new ModelAndView("customer/deleteCustomerProfileSuccess");
 		/*session.setAttribute("customer", customer);*/
		session.invalidate(); 
 		modelView.addObject("customerID",id);
		
		return modelView;
	}
	//////////////////////////////SELECT///////////////////////////////
	///////////SELECT Customer Page to Display/////////////////////////
	@RequestMapping(value = "/customer/selectACustomerID", method = RequestMethod.GET)
	public ModelAndView getACustomer(HttpServletRequest request,HttpSession session) {
		ModelAndView modelView;
		
 		modelView = new ModelAndView("customer/selectACustomerID");
 		modelView.addObject("customer", new Customer());
		return modelView;
	}
	///////////SELECT View Customer Detail Page/////////////////////////
	@RequestMapping(value = "/customer/viewACustomer", method = RequestMethod.GET)
	public ModelAndView viewCustomerDetail(@RequestParam (value = "customerID") String customerID) 
	{
		ModelAndView modelView;
		
		int id = Integer.parseInt(customerID);
		
		Customer customer = customerService.viewACustomer(id);
 		modelView = new ModelAndView("customer/selectACustomer");
 		modelView.addObject("customer", customer);
 		return modelView;
	}
	@RequestMapping(value = "/loginPage", method = RequestMethod.GET)
	public ModelAndView loginPage() 
	{
		ModelAndView modelView;
		
 		modelView = new ModelAndView("/loginPage");
 		//modelView.addObject("customer", new Customer());
 		return modelView;
	}
	@RequestMapping(value = "/loginCustomer", method = RequestMethod.POST)
	public ModelAndView loginCustomer(@RequestParam (value = "email") String email , HttpServletRequest request, HttpSession session) 
	{
		  // log the user in
		ModelAndView modelView;
		
		Customer customer = customerService.viewACustomer(email);
		
		if(customer== null)
		{
	 		modelView = new ModelAndView("/loginPage");
	 		modelView.addObject("error", "Error Username or Password is incorrect !");
	 		return modelView;
		}
		session.setAttribute("customer", customer);
 		modelView = new ModelAndView("/home");
 		modelView.addObject("customer", customer);
 		return modelView;
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(  HttpSession session) 
	{
		session.invalidate(); 	
		ModelAndView modelView;
		
 		modelView = new ModelAndView("/home");
 		//modelView.addObject("customer", new Customer());
 		return modelView;
	}
	//////////////////////////////UPDATE///////////////////////////////
	///////////UPDATE Customer.Take Customer ID to Display/////////////////////////
	@RequestMapping(value = "/customer/updateCustomerGetID", method = RequestMethod.GET)
	public ModelAndView updateACustomergetID(HttpSession session) {
		ModelAndView modelView;
		
		modelView = new ModelAndView("customer/updateGetCustomerID");
		modelView.addObject("customer", new Customer());
		return modelView;
	}
	///////////UPDATE Customer Page to Display/////////////////////////
	@RequestMapping(value = "/customer/updateCustomerDataForm", method = RequestMethod.GET)
	public ModelAndView updateACustomer(HttpSession session) {
		ModelAndView modelView;
		Customer customer  = (Customer) session.getAttribute("customer");
	/*	if(customer == null)
		{
			modelView = new ModelAndView("../loginPage");
	 		modelView.addObject("error", "Error Username or Password is incorrect !");
	 		return modelView;
		}*/
		int id = customer.getCustomerID();
 		modelView = new ModelAndView("customer/updateCustomerDataForm");
 		modelView.addObject("customer", customer);
		return modelView;
	}
	///////////UPDATE View Customer Success Page/////////////////////////
	@RequestMapping(value = "/customer/updateCustomerSuccess", method = RequestMethod.POST)
	public ModelAndView updateCustomerDetail(@Valid Customer customer, BindingResult result,HttpSession session) 
	{
		ModelAndView modelView;
		System.out.println("Before going ");
		Customer cust = customerService.updateCustomer(customer);
		System.out.println("returning now");
		session.setAttribute("customer", cust);
		System.out.println("Trying to print Cust id "+cust.getCustomerID());
 		modelView = new ModelAndView("customer/updateCustomerSuccess");
 		modelView.addObject("customerID", cust.getCustomerID());
 		return modelView;
	}
	/* Not for production code, just a demo of transaction rollback */
	/* If transactions are working, you should not see goodStudent in the database */
	
	@RequestMapping(value = "/testTransactions", method = RequestMethod.GET)
	public ModelAndView testTransactions() 
	{
		Customer goodStudent, badStudent;
		ModelAndView modelView;
		
		goodStudent = new Customer();
		goodStudent.setLastName("ValidStudent");
		goodStudent.setFirstName("Joe");
		customerService.addNewCustomer(goodStudent);
		
		modelView = new ModelAndView("studentUpdateResult");
		
		try {
			badStudent = new Customer();
			customerService.addNewCustomer(badStudent);
			modelView.addObject("resultMsg", "The Update was performed.");
		} catch (Exception ex) {  /* Exception from null student name */
			logger.info("Except+ion occurred as expected in testTransactions: " + ex);
			modelView.addObject("resultMsg", "Unable to perform the Customer Update!");
		}
		
		return modelView;
	}	
}
