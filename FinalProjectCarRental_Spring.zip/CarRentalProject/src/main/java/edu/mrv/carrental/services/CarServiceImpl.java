package edu.mrv.carrental.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.mrv.carrental.controllers.HomeController;
import edu.mrv.carrental.dao.CarDao;
import edu.mrv.carrental.domain.Car;

@Service
public class CarServiceImpl implements CarService {
	@Autowired
	@Qualifier("CarDaoJdbcImpl")
	private CarDao carDao;
	

	@Transactional
	public void addNewCar(Car car) {
		carDao.insertCar(car);
	}
	
	@Transactional
	public void removeCar (int id){
		carDao.deleteCar(id);
	}

	@Override
	public Car viewACar(int id) {
		return carDao.getACar(id);
		
	}
	
	@Override
	public Car updateCar(Car car) {
		return carDao.updateCar(car);
		
	}

	@Override
	public List<Car> viewAllCars() {
		return carDao.getAllCars();
		
	}

	@Override
	public List<Car> getSearchedCarsByVehicalClass(String vehical_class) {
		return carDao.getSearchedCarsByVehicalClass(vehical_class);
	}

}
