package edu.mrv.carrental.dao.jdbc;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import edu.mrv.carrental.dao.OrderMapper;
import edu.mrv.carrental.domain.Customer;
import edu.mrv.carrental.domain.Order;
import edu.mrv.carrental.dao.OrderDao;

@Repository("OrderDaoJdbcImpl")
public class OrderDaoJdbcImpl implements OrderDao{
	@Autowired
	private DataSource dataSource;
	private SimpleJdbcInsert jdbcInsert; 
	private JdbcTemplate jdbcTemplateObject;
	 
	@PostConstruct
	public void setup() {
		jdbcInsert = new SimpleJdbcInsert(dataSource);
		jdbcInsert.withTableName("rentalorder");
		jdbcInsert.usingGeneratedKeyColumns("RentalOrderID");
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
		
	}
	@Override
	public void insertOrder(Order order) {
			int id;
			SqlParameterSource paramSource = new BeanPropertySqlParameterSource(order);
			Number newId = jdbcInsert.executeAndReturnKey(paramSource);

			id = newId.intValue();
			order.setCustomerID(id);
	}
	@Override
	public List<Order> getOrdersDetailByCustomerID(int customerID) {
		// TODO Auto-generated method stub
		return null;
	}
}
