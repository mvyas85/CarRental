package edu.mrv.carrental.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import edu.mrv.carrental.domain.Order;

public class OrderMapper implements RowMapper<Order>
{
	@Override
   public Order mapRow(ResultSet rs, int rowNum) throws SQLException 
   {
      Order order = new Order();
      order.setOrderID(rs.getInt("orderID"));
      order.setCustomerID (rs.getInt("CustomerID "));
      order.setCarID(rs.getInt("carID"));
      order.setTotalDays(rs.getInt("TotalDays"));
      order.setStartDate(rs.getString("StartDate"));
      order.setEndDate(rs.getString("EndDate"));
      order.setRateApplied(rs.getDouble("RateApplied"));
      order.setAmount(rs.getDouble("Amount"));
      order.setTaxRate(rs.getDouble("TaxRate"));
      order.setTotal(rs.getDouble("Total"));
      
      return order;
   }
}