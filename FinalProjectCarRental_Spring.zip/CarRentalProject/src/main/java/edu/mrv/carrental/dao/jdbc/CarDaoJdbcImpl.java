package edu.mrv.carrental.dao.jdbc;

import java.sql.SQLException;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository; 
import com.mysql.jdbc.Statement;
import edu.mrv.carrental.dao.CarDao;
import edu.mrv.carrental.dao.CarMapper;
import edu.mrv.carrental.domain.Car;

@Repository("CarDaoJdbcImpl")
public class CarDaoJdbcImpl implements CarDao {
	@Autowired
	private DataSource dataSource;
	private SimpleJdbcInsert jdbcInsert;

	private JdbcTemplate jdbcTemplateObject;
	 
	@PostConstruct
	public void setup() {
		jdbcInsert = new SimpleJdbcInsert(dataSource);
		jdbcInsert.withTableName("car");
		
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
		
	}
	//CRUD = (create(insert), read(Select), update, delete).

	//insertTest
	
	@Override
	public void insertCar(Car car) 
	{			
		//This query i m not using but it wont work cause i have modified database a bit !! - Manisha
		final String SQL = "INSERT INTO `car_rental`.`car` (`make` ,`model` ,`carYear` ,`categoryID` ,`door` ,`picture` ,`condition` ,`available`)"
				+ " VALUES (?,?,?,?,?,?,?,?);";
		  
		final String tempMake = car.getMake();
		final String tempModel = car.getModel();
		final double tempRate = car.getRate();
		final int tempDoor = car.getDoor();
		final String tempPictire = car.getPicture();
		final int tempAvailable = car.getAvailable();

		KeyHolder keyHolder = new GeneratedKeyHolder();
	/*	Inserted row id: 47 (Query took 0.0612 sec)
		INSERT INTO `car_rental`.`car` (`carID` ,`make` ,`model` ,`carYear` ,`categoryID` ,`door` 
`picture` ,`condition` ,`available`)
		VALUES (
		NULL , 'Ferrari', 'F12 Berlinetta', '2013', NULL , '2', 'http://caronwhite.com/wp-content/uploads/2012/04/Ferrari-F12-berlinetta.png', 'new', '1'
		)*/

		jdbcTemplateObject.update(new PreparedStatementCreator() {           

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection arg0) throws SQLException 
			{
				java.sql.Connection conn = dataSource.getConnection();
				java.sql.PreparedStatement ps = conn.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS);
	                ps.setString(1, tempMake);
	                ps.setString(2, tempModel);
	                ps.setDouble(3, tempRate);
	                ps.setInt(4, tempDoor);
	                ps.setString(5, tempPictire);
	                ps.setInt(6, tempAvailable);
	                return ps;
			}
        }, keyHolder);
		car.setCarID(keyHolder.getKey().intValue());
		System.out.println("Created Record Name = " + car.getMake()+ " Model = " + car.getCarID());
		return; 
	}
	//selectTest
	@Override
	public Car getACar(int carID) 
	{
		Car car = null;
		try
		{
			String SQL = "select * from Car where carID = ?";
		    car= jdbcTemplateObject.queryForObject(SQL, new Object[]{carID}, new CarMapper());
		} 
		catch (EmptyResultDataAccessException e) 
		{
			System.out.println("Empty Result !");
		}
		return car;
	}
	@Override
	public List<Car> getAllCars() {
		List<Car> cars = null;
		try
		{
		
			String SQL = "select * from Car";
		    cars= jdbcTemplateObject.query	(SQL,new CarMapper());
		} 
		catch (EmptyResultDataAccessException e) 
		{
			System.out.println("Empty Result !");
		}
		return cars;
	}
	//updateTest
	@Override
	public Car updateCar(Car car)
	{
		
		String SQL="UPDATE `car_rental`.`car` SET "
				+ " `make` = ? ,"
				+ " `model` = ?,"
				+ " `carYear` = ?,"
				+ " `categoryID` = ?,"
				+ " `door` = ?,"
				+ " `picture` = ?,"
				+ " `condition` = ?,"
				+ " `available` = ? WHERE `car`.`carID` =?;";
				
				
/*				
				"UPDATE  car_rental.car  SET "
				+ "`make` = ?,"
				+ "`model` = ?,"
				+ "`carYear` = ?,"
				+ "`categoryID` =?,"
				+ "`door` = ?,"
				+ "`picture` = ?,"
				+ "`condition` = ?,"
				+ "`available` = ? WHERE `car.carID` = ?";*/
			// = "Update car set make = ? ,model = ? ,carYear= ?,categoryID = ? , door = ? , picture = ? , condition = ? ,available  = ?  WHERE car.carID = ?";  

			jdbcTemplateObject.update(SQL,
					car.getMake(),
					car.getModel(),
					car.getRate(),
					car.getDoor(),
					car.getPicture(),
					car.getAvailable(),
					car.getCarID());
			
			 System.out.println("Updated Record with ID = " + car.getCarID());
		    return getACar(car.getCarID());
		    
			
	}
	//delete
	@Override  
	public void deleteCar(int carID) 
	{  
		  String SQL = "delete from Car where carID = ?";
	      jdbcTemplateObject.update(SQL, carID);

	      System.out.println("Deleted Record with ID = " + carID );
	      return;
	}

	@Override
	public List<Car> getSearchedCarsByVehicalClass(String vehical_class) 
	{
		List<Car> cars = null;
		try
		{
		
			String SQL = "select * from Car where Vehical_class LIKE ?";
			System.out.println(SQL+" "+vehical_class);
		    cars= jdbcTemplateObject.query(SQL,new Object[]{vehical_class},new CarMapper());
		} 
		catch (EmptyResultDataAccessException e) 
		{
			System.out.println("Empty Result !");
		}
		return cars;
	}

}