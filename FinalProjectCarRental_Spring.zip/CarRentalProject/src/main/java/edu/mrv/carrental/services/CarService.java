package edu.mrv.carrental.services;

import java.util.List;

import edu.mrv.carrental.domain.Car;

public interface CarService {
	public List<Car> viewAllCars();
	public void addNewCar(Car car);
	public void removeCar(int id);
	public Car viewACar(int id);
	public Car updateCar(Car car);
	public List<Car> getSearchedCarsByVehicalClass(String vehical_class);
}
