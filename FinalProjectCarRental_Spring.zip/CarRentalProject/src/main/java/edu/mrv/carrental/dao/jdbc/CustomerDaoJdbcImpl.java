package edu.mrv.carrental.dao.jdbc;


import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository; 

import edu.mrv.carrental.dao.CustomerDao;
import edu.mrv.carrental.dao.CustomerMapper;
import edu.mrv.carrental.domain.Customer;

@Repository("CustomerDaoJdbcImpl")
public class CustomerDaoJdbcImpl implements CustomerDao {
	@Autowired
	private DataSource dataSource;
	private SimpleJdbcInsert jdbcInsert; 
	private JdbcTemplate jdbcTemplateObject;
	 
	@PostConstruct
	public void setup() {
		jdbcInsert = new SimpleJdbcInsert(dataSource);
		jdbcInsert.withTableName("customer");
		jdbcInsert.usingGeneratedKeyColumns("customerID");
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
		
	}

	//CRUD = (create(insert), read(Select), update, delete).

	//insert
	@Override
	public void insertCustomer(Customer cust) {
		int id;
		SqlParameterSource paramSource = new BeanPropertySqlParameterSource(cust);
		Number newId = jdbcInsert.executeAndReturnKey(paramSource);

		id = newId.intValue();
		cust.setCustomerID(id);
	}
	//selectTest
	@Override
	public Customer getACustomer(int custid) 
	{
		System.out.println(custid);
		Customer customer = null;
		try
		{
		
			String SQL = "select * from Customer where customerID = ?";
		    customer= jdbcTemplateObject.queryForObject(SQL, new CustomerMapper());
		} 
		catch (EmptyResultDataAccessException e) 
		{
			System.out.println("Empty Result !");
		}
		return customer;
	}

	@Override
	public Customer getACustomer(String email) {
		Customer customer = null;
		try
		{
		
			String SQL = "select * from Customer where email = ?";
		    customer= jdbcTemplateObject.queryForObject(SQL, new Object[]{email}, new CustomerMapper());
		} 
		catch (EmptyResultDataAccessException e) 
		{
			System.out.println("Empty Result !");
		}
		return customer;
	}
	//updateTest
	@Override
	public Customer updateCustomer(Customer cust)
	{
			String SQL = "Update customer set lastName = ? ,firstName = ? , drivLicNum  = ?,email = ? , address = ? , city = ? , state = ? ,zipCode  = ?  WHERE customerID = ?";  

			jdbcTemplateObject.update(SQL,cust.getLastName(),cust.getFirstName(), cust.getDrivLicNum(),cust.getEmail(),cust.getAddress(), cust.getCity(), cust.getState(),cust.getZipCode(),cust.getCustomerID() );
			
			 System.out.println("Updated Record with ID = " + cust.getCustomerID());
			 System.out.println("new Name is : " +cust.getFirstName());
		    return getACustomer(cust.getEmail());
	}
	//deleteTest
	@Override  
	public void delete(int id) 
	{  
		  String SQL = "delete from Customer where customerID = ?";
		  System.out.println(SQL+id);
	      jdbcTemplateObject.update(SQL, id);
	      System.out.println("Deleted Record with ID = " + id );
	      return;
	}

}