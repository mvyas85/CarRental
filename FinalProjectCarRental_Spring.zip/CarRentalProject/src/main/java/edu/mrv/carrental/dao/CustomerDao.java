package edu.mrv.carrental.dao;

import java.util.List;

import edu.mrv.carrental.domain.Customer;

public interface CustomerDao {
	public Customer getACustomer(int id); 
	public Customer getACustomer(String email); 
	public void insertCustomer(Customer cust);
	public void delete(int id);
	public Customer updateCustomer(Customer cust);
	
	//public List<Customer> getAllCustomer();
}
