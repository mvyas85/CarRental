package edu.mrv.carrental.dao;

import java.util.List;

import edu.mrv.carrental.domain.Order;

public interface OrderDao {
	public List<Order> getOrdersDetailByCustomerID(int customerID);
	public void insertOrder(Order order);
}
