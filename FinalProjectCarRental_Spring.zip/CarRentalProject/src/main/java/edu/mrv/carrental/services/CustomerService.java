package edu.mrv.carrental.services;

import edu.mrv.carrental.domain.Customer;

public interface CustomerService {
	public void addNewCustomer(Customer stud);
	public void removeCustomer(int id);
	public Customer viewACustomer(int id);
	public Customer viewACustomer(String email);
	public Customer updateCustomer(Customer cust);
}
