package edu.mrv.carrental.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import edu.mrv.carrental.domain.Customer;

public class CustomerMapper implements RowMapper<Customer>
{
   public Customer mapRow(ResultSet rs, int rowNum) throws SQLException 
   {
      Customer Customer = new Customer();
      Customer.setCustomerID(rs.getInt("customerID"));
      Customer.setEmail(rs.getString("email"));
      Customer.setPassword(rs.getString("password"));
      Customer.setFirstName(rs.getString("firstName"));
      Customer.setLastName(rs.getString("lastName"));
      Customer.setDrivLicNum(rs.getString("drivLicNum"));
      Customer.setAddress(rs.getString("address"));
      Customer.setCity(rs.getString("city"));
      Customer.setState(rs.getString("state"));
      Customer.setZipCode(rs.getInt("zipCode"));
      
      return Customer;
   }
}