package edu.mrv.carrental.dao;

import java.util.List;

import edu.mrv.carrental.domain.Car;

public  interface CarDao {
	public List<Car> getAllCars();
	public Car getACar(int id); 
	public void insertCar(Car car);
	public void deleteCar(int id);
	public Car updateCar(Car car);
	public List<Car> getSearchedCarsByVehicalClass(String vehical_class) ;
	
}
