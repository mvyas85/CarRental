package edu.mrv.carrental.dao.mock;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;

import edu.mrv.carrental.dao.CustomerDao;
import edu.mrv.carrental.domain.Customer;

@Repository("CustomerDaoMockImpl")
public class CustomerDaoMockImpl implements CustomerDao {
	private ArrayList<Customer> studList;
	static int idCnt = 1;
	
	@PostConstruct
	private void initData() {
		studList = new ArrayList<Customer>();
	}
	
	public void insertCustomer(Customer stud) {
		studList.add(stud);
		/* Simulate getting back the primary id from the database */
		stud.setCustomerID(idCnt);
		idCnt++;
	}
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer getACustomer(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Customer updateCustomer(Customer cust) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getACustomer(String email) {
		// TODO Auto-generated method stub
		return null;
	}
}
