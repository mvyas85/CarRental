package edu.mrv.carrental.dao.mock;

import java.util.List;

import edu.mrv.carrental.dao.CarDao;
import edu.mrv.carrental.domain.Car;

public class CarDaoMockImpl implements CarDao{

	@Override
	public Car getACar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertCar(Car car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCar(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Car updateCar(Car car) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Car> getAllCars() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Car> getSearchedCarsByVehicalClass(String vehical_class)  {
		// TODO Auto-generated method stub
		return null;
	}

}
