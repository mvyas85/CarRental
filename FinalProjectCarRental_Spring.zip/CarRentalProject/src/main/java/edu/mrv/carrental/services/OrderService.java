package edu.mrv.carrental.services;

import edu.mrv.carrental.domain.Order;

public interface OrderService {
	public void confirmOrder(Order order);
}
