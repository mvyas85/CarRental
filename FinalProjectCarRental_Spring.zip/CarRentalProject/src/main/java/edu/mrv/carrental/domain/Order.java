package edu.mrv.carrental.domain;

public class Order {
	private int orderID,customerID,carID,totalDays;
	private String startDate,endDate;
	private double rateApplied,amount,taxRate,total;
	
	public Order(){}
	public Order(int orderID, int customerID, int carID, int totalDays,
			String startDate, String endDate, double rateApplied,
			double amount, double taxRate, double total) {
		super();
		this.orderID = orderID;
		this.customerID = customerID;
		this.carID = carID;
		this.totalDays = totalDays;
		this.startDate = startDate;
		this.endDate = endDate;
		this.rateApplied = rateApplied;
		this.amount = amount;
		this.taxRate = taxRate;
		this.total = total;
	}
	public int getOrderID() {
		return orderID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public int getCarID() {
		return carID;
	}
	public int getTotalDays() {
		return totalDays;
	}
	public String getStartDate() {
		return startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public double getRateApplied() {
		return rateApplied;
	}
	public double getAmount() {
		return amount;
	}
	public double getTaxRate() {
		return taxRate;
	}
	public double getTotal() {
		return total;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public void setCarID(int carID) {
		this.carID = carID;
	}
	public void setTotalDays(int totalDays) {
		this.totalDays = totalDays;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public void setRateApplied(double rateApplied) {
		this.rateApplied = rateApplied;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setTaxRate(double taxRate) {
		this.taxRate = taxRate;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Order [orderID=" + orderID + ", customerID=" + customerID
				+ ", carID=" + carID + ", totalDays=" + totalDays
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", rateApplied=" + rateApplied + ", amount=" + amount
				+ ", taxRate=" + taxRate + ", total=" + total + "]";
	}
}
