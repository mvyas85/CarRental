package edu.mrv.carrental.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import edu.mrv.carrental.domain.Car;

public class CarMapper implements RowMapper<Car>
{
	@Override
   public Car mapRow(ResultSet rs, int rowNum) throws SQLException 
   {
		
      Car car = new Car();
      car.setCarID(rs.getInt("carID"));
      car.setMake(rs.getString("make"));
      car.setModel(rs.getString("model"));
      car.setVehical_class(rs.getString("vehical_class"));
      car.setRate(rs.getDouble("rate"));
      car.setDoor(rs.getInt("door"));
      car.setPicture(rs.getString("picture"));
      car.setAvailable(rs.getInt("available"));
      
      return car;
   }
}