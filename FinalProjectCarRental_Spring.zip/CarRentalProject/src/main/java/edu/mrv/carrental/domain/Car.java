package edu.mrv.carrental.domain;

import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Car {

	private int carID;	
	@NotEmpty
	private String make;	
	@NotEmpty
	private String model;
	private String vehical_class;
	
	private double rate;
	@Min(value=2)
	private int door;		
	@NotEmpty
	private String picture;	
	private int available;

	public Car(){}

	public Car(int carID, String make, String model, String vehical_class,
			double rate, int door, String picture, int available) {
		super();
		this.carID = carID;
		this.make = make;
		this.model = model;
		this.vehical_class = vehical_class;
		this.rate = rate;
		this.door = door;
		this.picture = picture;
		this.available = available;
	}


	public int getCarID() {
		return carID;
	}
	public String getMake() {
		return make;
	}
	public String getModel() {
		return model;
	}
	public int getDoor() {
		return door;
	}
	public String getPicture() {
		return picture;
	}
	public int getAvailable() {
		return available;
	}
	public double getRate() {
		return rate;
	}
	public String getVehical_class() {
		return vehical_class;
	}
	
	
	public void setCarID(int carID) {
		this.carID = carID;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setDoor(int door) {
		this.door = door;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
	public void setVehical_class(String vehical_class) {
		this.vehical_class = vehical_class;
	}
	@Override
	public String toString() {
		return "Car [carID=" + carID + ", make=" + make + ", model=" + model
				+ ", vehical_class=" + vehical_class + ", rate=" + rate
				+ ", door=" + door + ", picture=" + picture + ", available="
				+ available + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + available;
		result = prime * result + carID;
		result = prime * result + door;
		result = prime * result + ((make == null) ? 0 : make.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		result = prime * result + ((picture == null) ? 0 : picture.hashCode());
		long temp;
		temp = Double.doubleToLongBits(rate);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((vehical_class == null) ? 0 : vehical_class.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (available != other.available)
			return false;
		if (carID != other.carID)
			return false;
		if (door != other.door)
			return false;
		if (make == null) {
			if (other.make != null)
				return false;
		} else if (!make.equals(other.make))
			return false;
		if (model == null) {
			if (other.model != null)
				return false;
		} else if (!model.equals(other.model))
			return false;
		if (picture == null) {
			if (other.picture != null)
				return false;
		} else if (!picture.equals(other.picture))
			return false;
		if (Double.doubleToLongBits(rate) != Double
				.doubleToLongBits(other.rate))
			return false;
		if (vehical_class == null) {
			if (other.vehical_class != null)
				return false;
		} else if (!vehical_class.equals(other.vehical_class))
			return false;
		return true;
	}
	
}
