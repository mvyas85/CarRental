package edu.mrv.carrental.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.mrv.carrental.domain.Car;
import edu.mrv.carrental.domain.Customer;
import edu.mrv.carrental.domain.Order;
import edu.mrv.carrental.services.CarService;

@Controller
public class CarController {
	@Autowired
	CarService carService;
	
	//private static final Logger logger = LoggerFactory.getLogger(CarController.class);
	//////////////////////////////INSERT///////////////////////////////
	///////////INSERT Car Page/////////////////////////
	
	@RequestMapping(value = "/car/insertNewCarDataForm", method = RequestMethod.GET)
	public ModelAndView newCarDataForm() {
		ModelAndView modelView;
		
 		modelView = new ModelAndView("car/insertNewCarDataForm");
 		modelView.addObject("car", new Car());
		return modelView;
	}
	///////////INSERT Car Success Page/////////////////////////
	@RequestMapping(value = "/car/processNewCarProfile", method = RequestMethod.POST)
	public ModelAndView processNewCarForm(@Valid Car car, BindingResult result, HttpSession session) 
	{
		ModelAndView modelView;
		
		if (result.hasErrors()) {
			modelView = new ModelAndView("car/insertNewCarDataForm", "car", car);
			return modelView;
		}
		
		carService.addNewCar(car);
 		modelView = new ModelAndView("car/insertNewCarProfileSuccess");
 		session.setAttribute("car", car);
 		modelView.addObject("car", car);
		
		return modelView;
	}
	//////////////////////////////DELETE///////////////////////////////
	///////////DELETE Car Page to get ID/////////////////////////
	@RequestMapping(value = "/car/removeCarDataPage", method = RequestMethod.GET)
	public ModelAndView removeCarPage() {
		ModelAndView modelView;
		
 		modelView = new ModelAndView("/car/deleteCarDataPage");
 		modelView.addObject("car", new Car());
		return modelView;
	}
	///////////DELETE Car and Displays sucess/////////////////////////
	@RequestMapping(value = "/car/removeCarByID", method = RequestMethod.GET)
	public ModelAndView removeCarByID(@RequestParam (value = "carID") String carID) 
	{
		int id = Integer.parseInt(carID);
		
		carService.removeCar(id);
		ModelAndView modelView = new ModelAndView("car/deleteCarProfileSuccess");
 		/*session.setAttribute("car", car);*/
 		modelView.addObject("carID",id);
		
		return modelView;
	}
	//////////////////////////Car Search//////////////////////////
	//////////////////////Display Searched Car/////////////////////
	
	@RequestMapping(value = "/car/searchCar", method = RequestMethod.POST)
	public ModelAndView searchACar( @RequestParam (value = "vehical_class") String vehical_class,
									@RequestParam (value = "StartDate") String StartDate,
									@RequestParam (value = "EndDate") String EndDate,HttpServletRequest request, HttpSession session) 
	{
		ModelAndView modelView;
		
		List<Car> cars = carService.getSearchedCarsByVehicalClass(vehical_class);
 		modelView = new ModelAndView("car/viewSearchedCar");
 		Customer customer = (Customer) session.getAttribute("customer");
 		modelView.addObject("vehical_class", vehical_class);
 		modelView.addObject("StartDate", StartDate);
 		modelView.addObject("EndDate", EndDate);
 		modelView.addObject("customer", customer);
 		modelView.addObject("cars", cars);
 		
 		return modelView;
	}
	@RequestMapping(value = "/car/viewSelectedCar", method = RequestMethod.POST)
	public ModelAndView viewSelectedCar( @RequestParam (value = "vehical_class") String vehical_class,
									@RequestParam (value = "StartDate") String StartDate,
									@RequestParam (value = "EndDate") String EndDate,
									@RequestParam (value = "carID") int carID, HttpServletRequest request, HttpSession session) 
	{
		ModelAndView modelView;
		Car car = carService.viewACar(carID);
 		modelView = new ModelAndView("car/viewACar");
 		Customer customer = (Customer) session.getAttribute("customer");
 		//2014-04-02T14:01
 		
 		SimpleDateFormat formatter, FORMATTER;
 		formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
 		String oldStartDate = StartDate+":00";
 		String oldEndDate = EndDate+":00";
 		
 		Date StartDate_ =null,EndDate_= null;
		try {
			StartDate_ = formatter.parse(oldStartDate.substring(0,19));
			EndDate_ = formatter.parse(oldEndDate.substring(0,19));
	 		FORMATTER = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
	 		} catch (ParseException e) {
			e.printStackTrace();
		}
 		long diff = EndDate_.getTime()-StartDate_.getTime();
 		long totalDays = diff / (24 * 60 * 60 * 1000);
 		
 		double rateApplied = car.getRate();
 		double amount = rateApplied * totalDays;
 		double tax = 0.05 * amount; //Hardcoded tax taken 5%
 		double total = tax * amount;
 		
 		modelView.addObject("totalDays",totalDays);
 		modelView.addObject("rateApplied",rateApplied);
 		modelView.addObject("amount",amount);
 		modelView.addObject("tax",tax);
 		modelView.addObject("total",total);
 		modelView.addObject("vehical_class", vehical_class);
 		modelView.addObject("StartDate", StartDate);
 		modelView.addObject("EndDate", EndDate);
 		modelView.addObject("customer", customer);
 		modelView.addObject("car", car);
 		
 		return modelView;
	}
	//////////////////////////////SELECT///////////////////////////////
	///////////SELECT Car Page to Display/////////////////////////
	@RequestMapping(value = "/car/selectACarID", method = RequestMethod.GET)
	public ModelAndView getACar() {
		ModelAndView modelView;
		
 		modelView = new ModelAndView("car/selectACarID");
 		modelView.addObject("car", new Car());
		return modelView;
	}
	///////////SELECT View Car Detail Page/////////////////////////
	@RequestMapping(value = "/car/viewAllCars", method = RequestMethod.GET)
	public ModelAndView viewAllCarsDetail( HttpServletRequest request, HttpSession session) 
	{
		ModelAndView modelView;
		
		List<Car> cars = carService.viewAllCars();
 		modelView = new ModelAndView("car/viewAllCars");
 		Customer customer = (Customer) session.getAttribute("customer");
 		modelView.addObject("cars", cars);
 		modelView.addObject("customer", customer);
 		
 		return modelView;
	}
	@RequestMapping(value = "/car/viewACar", method = RequestMethod.GET)
	public ModelAndView viewCarDetail(@RequestParam (value = "carID") String carID) 
	{
		ModelAndView modelView;
		
		int id = Integer.parseInt(carID);
		
		Car car = carService.viewACar(id);
 		modelView = new ModelAndView("car/selectACar");
 		modelView.addObject("car", car);
 		return modelView;
	}
	//////////////////////////////UPDATE///////////////////////////////
	///////////UPDATE Car.Take Car ID to Display/////////////////////////
	@RequestMapping(value = "/car/updateCarGetID", method = RequestMethod.GET)
	public ModelAndView updateACargetID() {
		ModelAndView modelView;
		
		modelView = new ModelAndView("car/updateGetCarID");
		modelView.addObject("car", new Car());
		return modelView;
	}
	///////////UPDATE Car Page to Display/////////////////////////
	@RequestMapping(value = "/car/updateCarData", method = RequestMethod.GET)
	public ModelAndView updateACar(@RequestParam (value = "carID") String carID) {
		ModelAndView modelView;
		
		int id = Integer.parseInt(carID);
		
		Car car = carService.viewACar(id);
 		modelView = new ModelAndView("car/updateCarDataForm");
 		modelView.addObject("car", car);
		return modelView;
	}
	///////////UPDATE View Car Success Page/////////////////////////
	@RequestMapping(value = "/car/updateCarSuccess", method = RequestMethod.POST)
	public ModelAndView updateCarDetail(@Valid Car car, BindingResult result) 
	{
		ModelAndView modelView;
		Car cust = carService.updateCar(car);
 		modelView = new ModelAndView("car/updateCarSuccess");
 		modelView.addObject("carID", cust.getCarID());
 		return modelView;
	}	
}
