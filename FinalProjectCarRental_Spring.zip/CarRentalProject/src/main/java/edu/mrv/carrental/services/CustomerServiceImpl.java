package edu.mrv.carrental.services;

import java.util.ArrayList;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.mrv.carrental.controllers.HomeController;
import edu.mrv.carrental.dao.CustomerDao;
import edu.mrv.carrental.domain.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	@Qualifier("CustomerDaoJdbcImpl")
	private CustomerDao customerDao;
	

	@Transactional
	public void addNewCustomer(Customer cust) {
		customerDao.insertCustomer(cust);
	}
	
	@Transactional
	public void removeCustomer (int id){
		customerDao.delete(id);
	}

	@Override
	public Customer viewACustomer(int id) {
		return customerDao.getACustomer(id);
		
	}
	
	@Override
	public Customer updateCustomer(Customer cust) {
		return customerDao.updateCustomer(cust);
		
	}

	@Override
	public Customer viewACustomer(String email) {
		return customerDao.getACustomer(email);
	}

}
