
CREATE USER 'customerDbUser'@'localhost' IDENTIFIED BY 'spring';
GRANT ALL PRIVILEGES ON studentdb.* TO 'customerDbUser'@'localhost' WITH GRANT OPTION;
SHOW GRANTS FOR 'customerDbUser'@'localhost';

CREATE TABLE IF NOT EXISTS `customer` (
  `CustomerID` int(5) NOT NULL AUTO_INCREMENT,
  `DrivLicNum` varchar(7) NOT NULL,
  `FirstName` varchar(10) NOT NULL,
  `LastName` varchar(10) NOT NULL,
  `Email` varchar(15) NOT NULL,
  `Address` varchar(25) DEFAULT NULL,
  `City` varchar(10) NOT NULL,
  `State` varchar(10) NOT NULL,
  `ZipCode` int(5) NOT NULL,
  PRIMARY KEY (`CustomerID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `DrivLicNum`, `FirstName`, `LastName`, `Email`, `Address`, `City`, `State`, `ZipCode`) VALUES
(1, 'D123456', 'Manisha', 'Vyas', 'mee@google.com', '858 Living St Address ', 'Sunnyvale', 'Clifornia', 45625),
(2, 'D546786', 'Rajan', 'Vyas', 'hello@mail.com', '234 Some address', 'Newarkk', 'Navada', 54622),
(3, 'D434623', 'Siddh', 'Kumar', 'him@yahoo.com', '333 Fun Str', 'Dali City', 'Alberta', 56465),
(5, 'D789555', 'Den', 'Din', 'den@mail.com', 'his home add', 'Miniapolis', 'Texas', 45685),
(6, 'D152625', 'John', 'Winslet', 'her@mail.com', '123 Some street', 'Redwood', 'California', 55526),
(9, 'D152625', 'Jhon', 'Winslet', 'heri@mail.com', '123 Some street', 'Redwood', 'California', 55526);



CREATE TABLE IF NOT EXISTS `car` (
  `carID` int(5) NOT NULL AUTO_INCREMENT,
  `make` varchar(20) NOT NULL,
  `model` varchar(20) NOT NULL,
  `carYear` varchar(4) NOT NULL,
  `categoryID` int(5) DEFAULT NULL,
  `door` int(1) NOT NULL,
  `picture` varchar(150) NOT NULL,
  `condition` varchar(20) NOT NULL,
  `available` int(1) NOT NULL,
  PRIMARY KEY (`carID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`carID`, `make`, `model`, `carYear`, `categoryID`, `door`, `picture`, `condition`, `available`) VALUES
(48, 'Ferrari', 'F12 Berlinetta', '2013', 0, 2, 'abc', 'new', 1),
(49, 'Ferrari', 'F12 Berlinetta', '2013', 0, 2, 'abc', 'new', 1),
(50, 'Ferrari', 'F12 Berlinetta', '2013', 0, 2, 'abc', 'new', 1),
(51, 'Ferrari', 'F12 Berlinetta', '2013', 0, 2, 'abc', 'new', 1);



