package edu.mrv.carrental.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import edu.mrv.carrental.dao.CarDao;
import edu.mrv.carrental.dao.CarMapper;
import edu.mrv.carrental.domain.Car;

@ContextConfiguration("classpath:orderdao-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class CarDaoTest {

	Car car,car2;
	
	@Autowired
	@Qualifier("CarDaoJdbcImpl")
	CarDao custDao;
	
	//CRUD = (create(insert), read(Select), update, delete).
	@Before
	public void cleanDataSet()
	{
//		public Car(String make, String model, String carYear, String categoryID,
//				int door, String picture, String condition, boolean available)
		car = new Car  (0, "Ferrari", "F12 Berlinetta","Luxury", 10.10, 0, "abc", 1);
	}
	@After
	public void eraseDataSet()
	{
		//custDao.deleteCar(car.getCarID());
	}
	//insert
	@Test
	public void insertCarTest()
	{	
		custDao.insertCar(car);
		assertEquals(car, custDao.getACar(car.getCarID()));
	}
	//select
	@Test
	public void getACarTest() 
	{
		custDao.insertCar(car);
		
		Car tempCar = custDao.getACar(car.getCarID());
		assertEquals(car,tempCar);
	}
	//update
	@Test
	public void updateCarTest()
	{
		custDao.insertCar(car);
		car2 = new Car (0, "Ferrari", "F12 Berlinetta", "Luxury", 15.10, 0, "hdp", 5);
		car2.setCarID(car.getCarID());
		Car tempCar = custDao.updateCar(car2);
		assertEquals(car2,tempCar);
	}
	//delete
	@Test 
	public void deleteTest() 
	{  
	 	custDao.insertCar(car);
	 	int  addedCustID = car.getCarID();
	 	custDao.deleteCar(addedCustID);
		assertNull(custDao.getACar(addedCustID ));
	}
	
}
