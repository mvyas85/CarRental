package edu.mrv.carrental.test;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import edu.mrv.carrental.dao.CustomerDao;
import edu.mrv.carrental.domain.Customer;

@ContextConfiguration("classpath:orderdao-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class customerDaoTest {

	Customer cust,cust2;
	
	@Autowired
	@Qualifier("CustomerDaoJdbcImpl")
	CustomerDao custDao;
	
	//CRUD = (create(insert), read(Select), update, delete).

	@Before
	public void cleanDataSet()
	{
		cust = new Customer ("john@mail.com","john","Jhon","Winslet","D152625", "123 Some street","Redwood","California",55526);
	}
	@After
	public void eraseDataSet()
	{
		custDao.delete(cust.getCustomerID());
	}
	//insert
	@Test
	public void insertCustomerTest()
	{	
		custDao.insertCustomer(cust);
		assertEquals(cust, custDao.getACustomer(cust.getCustomerID()));
	}
	//select
	@Test
	public void getACustomerTest() 
	{
		custDao.insertCustomer(cust);
		
		Customer tempCustomer = custDao.getACustomer(cust.getCustomerID());
		assertEquals(cust,tempCustomer);
	}
	//update
	@Test
	public void updateCustomerTest()
	{
		custDao.insertCustomer(cust);
		cust2 = new Customer ("john@mail.com","john","Jhon","Winslet","D152625", "12 Change street","Redwood","California",55526);
		cust2.setCustomerID(cust.getCustomerID());
		Customer tempCust = custDao.updateCustomer(cust2);
		assertEquals(cust2,tempCust);
	}
	//delete
	@Test 
	public void deleteTest() 
	{  
	 	custDao.insertCustomer(cust);
	 	int  addedCustID = cust.getCustomerID();
	 	custDao.delete(addedCustID);
		assertNull(custDao.getACustomer(addedCustID ));
	}
}
