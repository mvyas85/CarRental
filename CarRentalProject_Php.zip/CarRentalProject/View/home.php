<!DOCTYPE html>
<html>
<head>
	<title>Manisha's Rental Home</title>
	<link rel="stylesheet" type="text/css" href="../resources/css/nav.css" />
	<link rel="stylesheet" type="text/css" href="../resources/css/style.css" />
	<link rel="stylesheet" type="text/css" href="../resources/css/search_box.css" />
</head>
<body>
    
        <?php include '../View/homeNavbar.php'; 
        
        if(!session_id()) 
        {
           session_start();
           session_cache_expire (21900);
        }
        if(isset($_SESSION['myusername']))
        {
               Echo "Welcome " . $_SESSION['myusername'].'!';
        }
        if(isset($_GET['messege']))    
        {
            echo '<p style="color:#FF0000;fornt-weight:bold;font-size:15px;">'.$_GET['messege'].'</p>';
        }
             
        ?>
        <div id="searchbox">
            <form action="../View/viewAllCars.php" method="Post">
                <input type="hidden" name="searching" value="searching"/>
                <div id="searchAcar">SEARCH CAR:</div>
                <br>
                <label style="font-weight: bold;">Pickup Date: (yyyy-mm-dd)</label>
                    <input type="text" name="pickup_date" value="2014-05-25" required=""/>
                <label style="font-weight: bold;">Hour : </label>
                            <select name="pickup_hour">
                                <?php
                                for($i=0;$i<25;$i++)
                                { 
                                    echo '<option>'.$i.'</option>';
                                }
                                ?>
                            </select>
                <label style="font-weight: bold;">Minute : </label>
                            <select name="pickup_min">
                                <?php
                                for($i=0;$i<60;$i++)
                                { 
                                    echo '<option>'.$i.'</option>';
                                }
                                ?>
                            </select><br/><br/>
                <label style="font-weight: bold;">Return Date: (yyyy-mm-dd)</label>
                <input type="text"  name="return_date" value="2014-05-30" required/>
                <label style="font-weight: bold;">Hour : </label>
                            <select name="return_hour">
                            <?php
                                for($i=0;$i<25;$i++)
                                { 
                                    echo '<option>'.$i.'</option>';
                                }
                            ?>
                            </select>
                <label style="font-weight: bold;">Minute : </label>
                            <select name="return_min">
                                <?php
                                for($i=0;$i<60;$i++)
                                { 
                                    echo '<option>'.$i.'</option>';
                                }
                                ?>
                            </select><br/><br/>
                <label style="font-weight: bold;">Vehical Class:</label>
                        <select name="vehical_class">
                            <option>Economy</option>
                            <option>Standard</option>
                            <option>Luxury</option>
                        </select>
                        <br/>
                        <br/>
                        <br/>
                        <center>
                            <input type="submit" id="submit" value="Search Car">
                        </center>
             </form>
        </div>
        <center>
            <img src="../resources/images/car_main_audi.jpg" >
        </center>
	</div>
</body>
</html>
