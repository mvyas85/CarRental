<?php
    require ('../Model/CarRepository.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>View All Car Information</title>
        <link rel="stylesheet" type="text/css" href="../resources/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="../resources/css/style.css" />
</head>
<body>
    <?php include '../View/homeNavbar.php'; 
    
    if(!session_id()) 
        {
           session_start();
           session_cache_expire (21900);
        }
        if(isset($_SESSION['myusername']))
        {
               Echo "Welcome " . $_SESSION['myusername'].'!';
        }
        ?>
    <div id="content">
    <h1>Our flee of car includes : </h1>
        
    <form action="../Controller/indexController.php" method="Post">
        <input type="hidden" name="confirm_booking" value="confirm_booking"/>
            <table id="allcars">
            
            <?php
            $carID= $_GET['carID'];
             $car = CarRepository::ViewACarsByID($carID);
            if(isset($_GET['searching']))
            {
                $pickup_date = $_GET['pickup_date'];
                $pickup_hour = $_GET['pickup_hour'];
                $pickup_min = $_GET['pickup_min'];
                $return_date = $_GET['return_date'];
                $return_hour = $_GET['return_hour'];
                $return_min = $_GET['return_min'];
                $vehical_class = $_GET['vehical_class'];
            ?>
            <tr>
                <td colspan="4">
                <table>
                    <tr>
                        <td>
                <fieldset>
                <legend>Order Info : </legend>
                <div >

                        <input type="hidden" name="searching" value="searching"/>
                        <div id="searchAcar">SEARCH CAR:</div>
                        <br>
                        <label style="font-weight: bold;">Pickup Date: (yyyy-mm-dd)</label>
                            <input type="text" name="pickup_date" value="<?php echo $pickup_date ; ?>" class="medium" readonly/>
                        <label style="font-weight: bold;">Hour : </label>
                            <input type="text" name="pickup_hour" value="<?php echo $pickup_hour ; ?>" class="small" readonly/>
                        <label style="font-weight: bold;">Minute : </label>
                            <input type="text" name="pickup_min" value="<?php echo $pickup_min ; ?>"class="small" readonly/>
                        <br>
                        <label style="font-weight: bold;">Return Date: (yyyy-mm-dd)</label>
                            <input type="text" name="return_date" value="<?php echo $return_date ; ?>"class="medium"  readonly/>
                        <label style="font-weight: bold;">Hour : </label>
                            <input type="text" name="return_hour" value="<?php echo $return_hour ; ?>" class="small" readonly/>
                        <label style="font-weight: bold;">Minute : </label>
                            <input type="text" name="return_min" value="<?php echo $return_min ; ?>"class="small" readonly/>
                        <br>
                        <br/><br/>
                        <center>
                        <label style="font-weight: bold;">Vehical Class:</label>
                            <input type="text" name="vehical_class" value="<?php echo $vehical_class ; ?>" class="medium"  readonly/>
                            <br>
                            <br>
                            <input type="button" onclick="window.location='./home.php';" value="Modify Search"/>
                        </center>
                </div>
                </fieldset>
                </td>
                <td >
                    <fieldset  >
                        <legend>Total Amount: </legend>
                        
                        <?php
                            $diff = abs(strtotime($return_date) - strtotime($pickup_date));

                            //$years = floor($diff / (365*60*60*24));
                            //$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                            $days = floor(($diff )/ (60*60*24));
                            $amount = $days * $car->getRate();
                            $tax = ($amount * 0.05);
                            $total=$tax+$amount;
                                
                        ?>
                        <div id="searchAcar">Order Information: </div>
                        <table>
                            <tr>
                                <td> <label>Total Days : </label></td>
                                <td>
                                    <input name="days" type="text" value="<?php echo $days ;?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Rate Applied : </label></td>
                                <td>
                                    $<input name="rate" type="text" value="<?php echo $car->getRate() ;?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Amount : </label></td>
                                <td>
                                    $<input name="amount" type="text" value="<?php echo $amount?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Tax (5%) : </label></td>
                                <td> 
                                    $<input name="tax" type="text" value="<?php echo $tax; ?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Total : </label></td>
                                <td>
                                    $<input name="total" type="text" value="<?php echo $total; ?>" class="medium" readonly/>
                                </td>
                            </tr>
                        </table>
                    </fieldset>
                </td>
                </tr>
                </table>
                </td>
          </tr>
          
            <?php
            }
            ?>
          <tr>
	  	<th>Make</th>
	        <th>Model</th>
	        <th>Picture</th>
	        <th>Details</th>
	    </tr>
            <tr>
                
                <td><a><?php echo $car->getMake(); ?></a></td>
                <td><?php echo $car->getModel()?></td>
                <td><img src="<?php echo $car->getPicture()?>" width="300px" height="150px"</td>
                <td>Vehical Class: <?php echo $car->getVehical_class() ?>
                    <br>Doors: <?php echo $car->getModel()?>
                    <br/>Rate per day : $<?php echo $car->getRate()?></td>
            </tr>
            <?php
            if(isset($_GET['searching']))
            {?>
            <tr>
                <td colspan="4">
                    <p style="font-weight: bold;color: #FF0000">By clicking on confirm booking button you are Agreeing to PAY using Credit Card On Account ! 
                        <br>And booking will be made under your name.
                        <br>Later you will be able to view or cancel all your booking from My Account menu option.
                    </p>
                </td
            </tr>
            <tr>
                <td colspan="4">
            <center>
                <input type="hidden" name="carID" value="<?php echo $car->getCarID(); ?>"/> 
                
                <input type="submit" id="submit" class="medium"value="Confirm Booking"/>
            </center>
                </td>
            </tr>
            <?php } ?>
	    </table>
</form>
</div>
</body>
</html>
        
  