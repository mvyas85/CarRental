<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
	<title>Ferrari Car Rental Home</title>
	<link rel="stylesheet" type="text/css" href="../resources/css/nav.css" />
	<link rel="stylesheet" type="text/css" href="../resources/css/style.css" />
	<link rel="stylesheet" type="text/css" href="../resources/css/search_box.css" />
</head>
<body>
    
        <?php include '../View/homeNavbar.php'; ?>
        
        <div id="content">
            <h1>Our flee of car includes : </h1>
	  <table id="allcars">
              <tr><td>
        <fieldset>
            <legend>Edit My Account Information</legend>
            
            <table id="allcars"   >
                <tr >
                <p style="text-align: center;font-size:20px;color:#FF0000">
                <?php
                if(isset($_GET['messege']))    
                    {
                        echo $_GET['messege'];
                    }
                    ?>
            <form name="form1" method="post" action="../Controller/indexController.php"  id="palinForm">
            <input type='hidden' name='edit_acc' value='edit_acc'/>
                
            <table id="editor" style="padding-left:0px;" >
                <tr>
                    <td>Email Address (UserName)*:</td>
                    <td><input type="text"  name="newusername" value="<?php echo  $_SESSION['myemail']; ?>" maxlength="50" readonly/></td>
                </tr>
                <tr>
                    <td>Password*:</td>
                    <td><input type='password' name='newpassword' value="<?php echo $_SESSION['mypassword']; ?>" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>Confirm Password*:</td>
                    <td><input type='password' name='confirmnewpassword' value="" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>First Name*:</td>
                    <td><input type="text"  name="newfirstName" value="<?php echo $_SESSION['myusername']; ?>" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>Last Name*:</td>
                    <td><input type='text' name='newlastName' value="<?php echo $_SESSION['mylastName']; ?>" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>Driver License Number*:</td>
                    <td><input type='text' name='newdrivLicNum' value="<?php echo $_SESSION['mydrivLicNum']; ?>" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>Address*:</td>
                    <td><input type='text' name='newaddress' value="<?php echo $_SESSION['myAddress']; ?>" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>City*:</td>
                    <td><input type='text' name='newcity' value="<?php echo $_SESSION['myCity']; ?>" id='password' maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>State*:</td>
                    <td><input type='text' name='newstate' value="<?php echo $_SESSION['myState']; ?>" maxlength="50" required/></td>
                </tr>
                <tr>
                    <td>Zip Code:</td>
                    <td><input type='text' name='newzipCode' value="<?php echo $_SESSION['myZipCode']; ?>" maxlength="10"/></td>
                </tr>
            </table>
            <input type='submit' name='Submit' value='Create Account'  id='submit' />
            </form>
        </fieldset>
                  </td></tr>
                  </table>
    </div>
    </body>
</html>
