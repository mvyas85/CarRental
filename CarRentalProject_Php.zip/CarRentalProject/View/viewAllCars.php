<?php
    require ('../Model/CarRepository.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>View All Car Information</title>
        <link rel="stylesheet" type="text/css" href="../resources/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="../resources/css/style.css" />
</head>
<body>
    <?php include '../View/homeNavbar.php'; 
    if(!session_id()) 
        {
           session_start();
           session_cache_expire (21900);
        }
        if(isset($_SESSION['myusername']))
        {
               Echo "Welcome " . $_SESSION['myusername'].'!';
        }
    ?>
    <div id="content">
    <h1>Our flee of car includes : </h1>
    <form name="form1" action="../View/viewACar.php" method="Post">
	  <table id="allcars">
	  
            <tr>
                <td colspan="4">
            <?php
            if(isset($_POST['searching']))
            {
                $pickup_date = $_POST['pickup_date'];
                $pickup_hour = $_POST['pickup_hour'];
                $pickup_min = $_POST['pickup_min'];
                $return_date = $_POST['return_date'];
                $return_hour = $_POST['return_hour'];
                $return_min = $_POST['return_min'];
                $vehical_class = $_POST['vehical_class'];
            ?>
                
            <fieldset>
            <legend>Search for</legend>
            <div >

                    <input type="hidden" name="searching" value="searching"/>
                    <div id="searchAcar">SEARCH CAR:</div>
                    <br>
                    <label style="font-weight: bold;">Pickup Date: (yyyy-mm-dd)</label>
                        <input type="text" name="pickup_date" value="<?php echo $pickup_date ; ?>" class="medium" readonly/>
                    <label style="font-weight: bold;">Hour : </label>
                        <input type="text" name="pickup_hour" value="<?php echo $pickup_hour ; ?>" class="small" readonly/>
                    <label style="font-weight: bold;">Minute : </label>
                        <input type="text" name="pickup_min" value="<?php echo $pickup_min ; ?>"class="small" readonly/>
                    <br>
                    <label style="font-weight: bold;">Return Date: (yyyy-mm-dd)</label>
                        <input type="text" name="return_date" value="<?php echo $return_date ; ?>"class="medium"  readonly/>
                    <label style="font-weight: bold;">Hour : </label>
                        <input type="text" name="return_hour" value="<?php echo $return_hour ; ?>" class="small" readonly/>
                    <label style="font-weight: bold;">Minute : </label>
                        <input type="text" name="return_min" value="<?php echo $return_min ; ?>"class="small" readonly/>
                    <br>
                    <br/><br/>
                    <center>
                    <label style="font-weight: bold;">Vehical Class:</label>
                        <input type="text" name="vehical_class" value="<?php echo $vehical_class ; ?>" class="medium" readonly/>
                        <br>
                        <br>
                        <input type="button" onclick="window.location='./home.php';" value="Modify Search"/>
                    </center>
            </div>
            </fieldset>
                </td>
          </tr>
          <tr>
              <td colspan="4">
          <center>
                  <p style="color:#FF0000;fornt-weight:bold;">Click on Car to Select</p>
          </center>
              </td>
          </tr>
            <tr>
	  	<th>Make</th>
	        <th>Model</th>
	        <th>Picture</th>
	        <th>Details</th>
	    </tr> 
            <?php
            }
            if(isset($vehical_class))
            {
                $cars = CarRepository::searchByVehicalClass($vehical_class);
            }
            else
            {
                $cars = CarRepository::ViewAllCars();
            }
            foreach($cars as $car)
            {
            ?>
                    <tr>
                        <td><a><?php echo $car->getMake(); ?></a></td>
                        <td><?php echo $car->getModel()?></td>
                        <?php 
                            if(isset($_POST['searching']))
                            {
                                $link='./viewACar.php?carID='.$car->getCarID().'&searching=searching'
                                        . '&pickup_date='.$pickup_date
                                        . '&pickup_hour='.$pickup_hour
                                        . '&pickup_min='.$pickup_min
                                        . '&return_date='.$return_date
                                        . '&return_hour='.$return_hour
                                        . '&return_min='.$return_min
                                        . '&vehical_class='.$vehical_class;
                            }
                            else
                            {
                                $link='./viewACar.php?carID='.$car->getCarID();
                            }
                            
                            ?>
                        <td>
                            <input type="hidden" name="carID" value="<?php echo $car->getCarID()?>"/>
                            <a href="<?php echo $link; ?>" onclick="document.form1.submit();">
                                <image src="<?php echo $car->getPicture()?>" />
                            </a>
                            
                        <td>Vehical Clas: <?php echo $car->getVehical_class() ?>
                            <br>Doors: <?php echo $car->getModel()?>
                            <br/>Rate per day : $<?php echo $car->getRate()?></td>
                    </tr>
            <?php
            }
	    ?>	 
	    </table>
</form>
 	</div>
</body>
</html>
