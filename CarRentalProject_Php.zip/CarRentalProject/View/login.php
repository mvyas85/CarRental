<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link type="text/css" rel="stylesheet" href="../resources/css/style.css"/>
        <link type="text/css" rel="stylesheet" href="../resources/css/nav.css"/>
        <title>Login</title>
    </head>
    <body>
        <?php include '../View/homeNavbar.php'; ?>
        <div id="content"style="padding-top:50px;">
            <?php 
            //echo $loginerror; 
       
            if(isset($passwordDonotMatch))
            {
                echo $passwordDonotMatch;                
            }?>
            <table id="allcars"   >
                <tr >
                <p style="text-align: center;font-size:20px;color:#FF0000">
                    <?php
                    if(isset($_GET['error']))    
                        {
                            echo $_GET['error'];
                        }
                        ?>
                </p>
                    <td style="padding-right:30px;"> <fieldset>
                        
                        <legend>Login</legend>
                        <form name="form1" method="post" action="../Controller/indexController.php" id="palinForm">
                        <input type='hidden' name='loggingin'  value='loggingin'/>

                        <table id="editor" style="padding-left:0px;" >
                            <tr>
                                <td>UserName*:</td>
                                <td><input type='text' name='myusername' id='username' maxlength="50" /></td>
                            </tr>
                            <tr>
                                <td>Password*:</td>
                                <td><input type='password' name='mypassword' id='password'  maxlength="50" /></td>
                            </tr>
                        </table>
                        <input type='submit' name='Submit' value='Login'  id='submit' />
                        </form>
                    </fieldset>
                    </td>
                    <td>
                        <fieldset>
                            <legend>Create New User</legend>
                            <form name="form1" method="post" action="../Controller/indexController.php"  id="palinForm">
                            <input type='hidden' name='create_user' value='create_user'/>

                            <table id="editor" style="padding-left:0px;" >
                                <tr>
                                    <td>Email Address (UserName)*:</td>
                                    <td><input type="text"  name="newusername" maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>Password*:</td>
                                    <td><input type='password' name='newpassword'  maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>Confirm Password*:</td>
                                    <td><input type='password' name='confirmnewpassword' maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>First Name*:</td>
                                    <td><input type="text"  name="newfirstName" maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>Last Name*:</td>
                                    <td><input type='text' name='newlastName'  maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>Driver License Number*:</td>
                                    <td><input type='text' name='newdrivLicNum' maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>Address*:</td>
                                    <td><input type='text' name='newaddress' maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>City*:</td>
                                    <td><input type='text' name='newcity' id='password' maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>State*:</td>
                                    <td><input type='text' name='newstate' maxlength="50" required/></td>
                                </tr>
                                <tr>
                                    <td>Zip Code:</td>
                                    <td><input type='text' name='newzipCode'maxlength="10"/></td>
                                </tr>
                            </table>
                            <input type='submit' name='Submit' value='Create Account'  id='submit' />
                            </form>
                        </fieldset>
                    </td>
                </tr>
            </table>
          </div>
    </body>
</html>


<!--<!DOCTYPE html>
<html>
<head>
	<title>View Customer Information</title>
	<link rel="stylesheet" type="text/css" href="../resources/css/style.css" />
	
</head>
<body>
    <?php //include '../View/homeNavbar.php'; ?>
    <div id="content">
	<h1>Login or create account </h1>
	  <form action='' method="POST" name="form1">
	  <table>
	  	 <tr>
	  		<td padding-right="30px">Login ID (email address): </td>
	     	<td><input type="text" name="email"/></td>
     	</tr>
     	 <tr>
	    <td><br/></td>
	    </tr>
     	<tr>
	     	<td>password : </td>
	     	<td><input type="text" name="password"/></td>
	    </tr>
	    <tr><td>
	    <br/></td>
	    </tr>
	  
		<tr>
	    <td><input type="submit" id="submit" value="Login"  onClick="form1.action='./loginCustomer.php'"> </td>
	    </tr>
	    <tr>
	    <td><br/></td>
	    </tr>
	    <tr>
	    <td><input type="submit" id="submit" value="Create Account"  onClick="form1.action='./customer/insertNewCustomerDataForm.php'" /> </td>
	    </tr>
	    </table>
	  </form>
 	</div>
</body>
</html>

-->
