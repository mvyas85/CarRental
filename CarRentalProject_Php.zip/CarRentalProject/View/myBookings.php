<?php
    require ('../Model/OrderRepository.php');
    require ('../Model/CarRepository.php');
    
?>
<!DOCTYPE html>
<html>
<head>
	<title>My Bookings</title>
        <link rel="stylesheet" type="text/css" href="../resources/css/nav.css" />
        <link rel="stylesheet" type="text/css" href="../resources/css/style.css" />
</head>
<body>
    <?php include '../View/homeNavbar.php'; 
    
    if(!session_id()) 
    {
       session_start();
       session_cache_expire (21900);
    }
    if(isset($_SESSION['myusername']))
    {
           Echo "Welcome " . $_SESSION['myusername'].'!';
    }
    
    $orders = OrderRepository::viewOrdersForCustomer($_SESSION['myCustID']);
    ?>
    <div id="content">
    <h1>View My Bookings: </h1>
         <?php
            $x =0;
            foreach($orders as $order)
            {
                $x++;
                $orderID=$order->getOrderID();
                $carID= $order->getCarID();
                $car = CarRepository::ViewACarsByID($carID);

                $startDate = $order->getStartDate();
                $endDate = $order->getEndDate();
                $totalDays = $order->getTotalDays();
                $rateApplied=$order->getRateApplied();
                $amount=$order->getAmount();
                $tax=$order->getTax();
                $total=$order->getTotal();
                
                $vehical_class=$car->getVehical_class();
                $make=$car->getMake();
                $model=$car->getModel();
                $picture=$car->getPicture();
                $door=$car->getDoor();
                $rate=$car->getRate();
            ?>
            <h1>Booking<?php echo $x; ?> </h1>
            <table id="allcars">
            <tr>
                <td colspan="4">
                <table>
                    <tr>
                        <td>
                <fieldset>
                <legend>Order Info :  </legend>
                <div >

                        <input type="hidden" name="searching" value="searching"/>
                        <div id="searchAcar">Order ID : <?php echo $orderID ;?></div>
                        <br>
                        <label style="font-weight: bold;">Pickup Date: (yyyy-mm-dd)</label>
                            <input type="text" name="pickup_date" value="<?php echo $startDate ; ?>"  readonly/>
                        <br>
                        <label style="font-weight: bold;">Return Date: (yyyy-mm-dd)</label>
                            <input type="text" name="return_date" value="<?php echo $endDate ; ?>" readonly/>
                        <br>
                        <br/><br/>
                        <center>
                        <label style="font-weight: bold;">Vehical Class:</label>
                            <input type="text" name="vehical_class" value="<?php echo $vehical_class ; ?>" class="medium"  readonly/>
                        </center>
                </div>
                </fieldset>
                </td>
                <td >
                    <fieldset  >
                        <legend>Total Amount: </legend>
                       
                        <div id="searchAcar">Order Information: </div>
                        <table>
                            <tr>
                                <td> <label>Total Days : </label></td>
                                <td>
                                    <input name="days" type="text" value="<?php echo $totalDays ;?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Rate Applied : </label></td>
                                <td>
                                    $<input name="rate" type="text" value="<?php echo $rateApplied ;?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Amount : </label></td>
                                <td>
                                    $<input name="amount" type="text" value="<?php echo $amount?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Tax (5%) : </label></td>
                                <td> 
                                    $<input name="tax" type="text" value="<?php echo $tax; ?>" class="medium" readonly/>
                                </td>
                            </tr>
                            <tr>
                                <td><label>Total : </label></td>
                                <td>
                                    $<input name="total" type="text" value="<?php echo $total; ?>" class="medium" readonly/>
                                </td>
                            </tr>
                        </table>
                    </fieldset>
                </td>
                </tr>
                </table>
                </td>
          </tr>
          <tr>
	  	<th>Make</th>
	        <th>Model</th>
	        <th>Picture</th>
	        <th>Details</th>
	    </tr>
            <tr>
                
                <td><a><?php echo $make; ?></a></td>
                <td><?php echo $model?></td>
                <td><img src="<?php echo $picture?>" width="300px" height="150px"</td>
                <td>Vehical Class: <?php echo $vehical_class ?>
                    <br>Doors: <?php echo $door?>
                    <br/>Rate per day : $<?php echo $rateApplied?></td>
            </tr>
            <tr>
                <td colspan="4">
            <center>
                <input type="submit" id="submit" value="Cancel This Booking" onclick="window.location='../Controller/indexController.php?cancel=<?php echo $orderID ;?>';" />  
            </center>
                </td>
            </tr>
	    </table>
    <?php
    }
    ?>
</div>
</body>
</html>
        
  