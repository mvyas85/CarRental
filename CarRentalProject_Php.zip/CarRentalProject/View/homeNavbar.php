<link rel="stylesheet" type="text/css" href="../resources/css/nav.css" />
<link rel="stylesheet" type="text/css" href="../resources/css/style.css" />

<div id="wrap">
<nav float="right">
  <ul id="menu" >
      <li><a href="../Controller/indexController.php">HOME</a> 
	<li><a href="./viewAllCars.php?vehical_class=All">Our Fleet</a></li>
	<?php 
        
        if(!session_id()) 
             {
                session_start();
                session_cache_expire (21900);
             }
             if(isset($_SESSION['myusername']))
             {
                ?>
                <li><a href="#">My Account</a>
                    <ul>
                        <li><a href="../View/myBookings.php">My Bookings</a>
                        <li><a href="../View/editAccInfo.php">Account Information</a>
                        <li><a href="../Controller/indexController.php?del=<?php echo $_SESSION['myusername']; ?>">DELETE My Account</a>
                    </ul>
                </li>
                <?php
            }
         
            if(!isset($_SESSION['myusername']))
            {
		echo '<li><a href="../View/login.php">Login</a></li>';
            }
            else
            {?>
                <li><a href="../Controller/indexController.php?logout='logout'">Logout</a></li>
                <?php
            }
        ?>
  </ul>
</nav>	
	
	
	