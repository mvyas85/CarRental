<?php
require ('../Model/db_connect.php');
require ('../Model/Customer.php');

class CustomerRepository 
{
    //To check users login before updating password
    public static function confirmLogIn($myusername,$mypassword) 
    {
        $db = DBConnect::getDB();
        $query ="SELECT * FROM customer WHERE Email='$myusername' and password='$mypassword'";
        $rows = $db->prepare($query);
        $rows->execute();

        $count = $rows->rowCount();
        return $count ;
    } 
    //To view all the cars from database
    public static function getACustomerByFirstName($firstName) 
    { 
        $db = DBConnect::getDB();
        $query = " select * from customer where FirstName = '$firstName';";
        
        $result = $db->query($query);
        foreach ($result as $row) 
        {
            $customer = new Customer($row['CustomerID'],$row['Email'],$row['password'],$row['FirstName'],$row['LastName'],$row['DrivLicNum'],$row['Address'],$row['City'],$row['State'],$row['ZipCode']); 
        }
        return $customer;
    }
    //get a Customer using ID   
    public static function  getACustomerByEmail($email) 
    {
        $db = DBConnect::getDB();
        $query = " select * from customer where email='$email';";
    
        $result = $db->query($query);
        foreach ($result as $row) 
        {
            $customer = new Customer($row['CustomerID'],$row['Email'],$row['password'],$row['FirstName'],$row['LastName'],$row['DrivLicNum'],$row['Address'],$row['City'],$row['State'],$row['ZipCode']); 
        }
        return $customer;
    }
    
    //Provides Combine table info
    public static function deleteCustomer($firstName) 
    {
        $db = DBConnect::getDB();
        $query = "delete from customer where FirstName = '$firstName' ;";
        
        
        $result = $db->exec($query);
        return $result;
    }
    
    //Create new Customer
    public static function createNewCustomer($email,$password,$firstName,$lastName,$drivLicNum,$address,$city,$state,$zipCode) 
    {
        $db = DBConnect::getDB();
        $query ="INSERT INTO `car_rental`.`customer` (
                `Email` ,
                `password` ,
                `FirstName` ,
                `LastName` ,
                `DrivLicNum` ,
                `Address` ,
                `City` ,
                `State` ,
                `ZipCode`
                )
                VALUES ('$email','$password','$firstName','$lastName','$drivLicNum','$address','$city','$state',$zipCode);";
        
        $rows = $db->prepare($query);
        $rows->execute();

        $count = $rows->rowCount();
        return $count ;
    }
    
    //update a Customer
    public static function updateCustomer($id,$email,$password,$firstName,$lastName,$drivLicNum,$address,$city,$state,$zipCode) 
    {
        $db = DBConnect::getDB();
        $query = "UPDATE `car_rental`.`customer` SET 
                `Email` = '$email' ,
                `password` = '$password',
                `FirstName` ='$firstName' ,
                `LastName` ='$lastName',
                `DrivLicNum` ='$drivLicNum',
                `Address` ='$address',
                `City` ='$city',
                `State` ='$state',
                `ZipCode`= $zipCode where CustomerID= $id;";
        
        $result = $db->exec($query);
        return $result;
    }
}
