<?php
require_once  ('../Model/db_connect.php');
require ('../Model/Car.php');

class CarRepository 
{
    //To view all the cars from database
    public static function ViewAllCars() 
    { 
        $db = DBConnect::getDB();
        $query = " select * from car;";
        
        $result = $db->query($query);
        $all_cars = array();
        foreach ($result as $row) 
        {
            $cars = new Car($row['carID'],$row['make'],$row['model'],$row['vehical_class'],$row['rate'],$row['door'],$row['picture'],$row['available']);
            $all_cars[] = $cars;
        }
        return $all_cars;
    }
    
    //To view all the cars from database
    public static function ViewACarsByID($id) 
    { 
        $db = DBConnect::getDB();
        $query = " select * from car where carID = $id;";
        
        $result = $db->query($query);
        $all_cars = array();
        foreach ($result as $row) 
        {
            $car = new Car($row['carID'],$row['make'],$row['model'],$row['vehical_class'],$row['rate'],$row['door'],$row['picture'],$row['available']);
        }
        return $car;
    }
    
    //Search car by vehical_class
    public static function searchByVehicalClass($vehical_class) 
    { 
        $db = DBConnect::getDB();
        $query = " select * from car where Vehical_class LIKE '%$vehical_class%'";
        
        $result = $db->query($query);
        $class_cars = array();
        foreach ($result as $row) 
        {     
            $cars = new Car($row['carID'],$row['make'],$row['model'],$row['vehical_class'],$row['rate'],$row['door'],$row['picture'],$row['available']);
            $class_cars[] = $cars;
        }
        return $class_cars;
    }
}
