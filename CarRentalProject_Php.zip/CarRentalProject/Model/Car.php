<?php

class Car{
       private $carID,$make,$model,$vehical_class,$rate,$door,$picture, $available;
    
    public function __construct($carID,$make,$model,$vehical_class,$rate,$door,$picture,$available)
    {
        $this->carID=$carID;
        $this->make=$make;
        $this->model=$model;
        $this->vehical_class=$vehical_class;
        $this->rate=$rate;
        $this->door=$door;
        $this->picture=$picture;
        $this->available=$available;
    }
    
    public function getCarID(){ return $this->carID;}
    public function getMake(){ return $this->make;}
    public function getModel(){ return $this->model;}
    public function getVehical_class(){ return $this->vehical_class;}
    public function getRate(){ return $this->rate;}
    public function getDoor(){ return $this->door;}
    public function getPicture(){ return $this->picture;}
    public function getAvailable(){ return $this->available;}
    
    public function setCarID($carID)
    {
        $this->carID=$carID;
    }
    public function setMake($make)
    { 
        $this->make=$make;
    }
    public function setModel($model)
    { 
        $this->model=$model;
    }
    public function setVehical_class($vehical_class)
    { 
        $this->vehical_class=$vehical_class;
    }
    public function setRate($rate)
    { 
        $this->rate=$rate;
    }
    public function setDoor($door)
    { 
        $this->door=$door;
    }
    public function setPicture($picture)
    { 
        $this->picture=$picture;    
    }
    public function setAvailable($avilable)
    { 
        $this->available=$avilable;    
    }
}