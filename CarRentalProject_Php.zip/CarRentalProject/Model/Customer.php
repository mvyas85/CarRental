<?php

class Customer{
    private $customerID,$email,$password,$firstName,$lastName,$drivLicNum,$address,$city,$state,$zipCode;
   
    
    public function __construct($customerID,$email,$password,$firstName,$lastName,$drivLicNum,$address,$city,$state,$zipCode)
    {
        $this->customerID=$customerID;
        $this->email=$email;
        $this->password=$password;
        $this->firstName=$firstName;
        $this->lastName=$lastName;
        $this->drivLicNum=$drivLicNum;
        $this->address=$address;
        $this->city=$city;
        $this->state=$state;
        $this->zipCode=$zipCode;
    }
    
    public function getcustomerID(){ return $this->customerID;}
    public function getEmail(){ return $this->email;}
    public function getPassword(){ return $this->password;}
    public function getFirstName(){ return $this->firstName;}
    public function getLastName(){ return $this->lastName;}
    public function getDrivLicNum(){ return $this->drivLicNum;}
    public function getAddress(){ return $this->address;}
    public function getCity(){ return $this->city;}
    public function getState(){ return $this->state;}
    public function getZipCode(){ return $this->zipCode;}
    
    public function setcustomerID($customerID)
    {
        $this->customerID=$customerID;
    }
    public function setEmail($email)
    { 
        $this->email=$email;
    }
    public function setPassword($password)
    { 
        $this->password=$password;
    }
    public function setFirstName($firstName)
    { 
        $this->firstName=$firstName;
    }
    public function setLastName($lastName)
    { 
        $this->lastName=$lastName;
    }
    public function setDrivLicNum($drivLicNum)
    { 
        $this->drivLicNum=$drivLicNum;    
    }
    public function setAddress($address)
    { 
        $this->address=$address;    
    }
     public function setCity($city)
    { 
        $this->city=$city;
    }
    public function setState($state)
    { 
        $this->state=$state;    
    }
    public function setZipCode($zipCode)
    { 
        $this->zipCode=$zipCode;    
    }
}