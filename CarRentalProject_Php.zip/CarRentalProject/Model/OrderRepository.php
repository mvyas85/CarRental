<?php
require_once('../Model/db_connect.php');
require ('../Model/Order.php');
class OrderRepository
{
    
     //Provides Combine table info
    public static function deleteOrderByOrderID($orderID) 
    {
        $db = DBConnect::getDB();
        $query = "delete from rentalorder where RentalOrderID = '$orderID' ;";
        
        $result = $db->exec($query);
        return $result;
    }
    
    //View all Oreder for Customer
    public static function viewOrdersForCustomer($customerID)
    {
        $db = DBConnect::getDB();
        $query ="select * from rentalorder where CustomerID = $customerID";
        
        $result = $db->query($query);
        
        $all_orders = array();
        foreach ($result as $row) 
        {
            $order = new Order($row['RentalOrderID'],$row['CustomerID'],$row['CarID'],$row['StartDate'],$row['EndDate'],$row['TotalDays'],$row['RateApplied'],$row['Amount'],$row['TaxRate'],$row['Total']); 
            $all_orders[] = $order; 
        }
        return $all_orders;
    }
    //Create new Oreder
    public static function createNewOrder($customerID,$carID,$startDate,$endDate,$totalDays,$rateApplied,$amount,$tax,$total)
    {
        $db = DBConnect::getDB();
        $query ="INSERT INTO `car_rental`.`rentalorder` (
                `CustomerID` ,
                `CarID` ,
                `StartDate` ,
                `EndDate` ,
                `TotalDays` ,
                `RateApplied` ,
                `Amount` ,
                `TaxRate`,
                `Total`
                )
                VALUES ('$customerID','$carID','$startDate','$endDate','$totalDays','$rateApplied','$amount','$tax','$total');";
        
        $rows = $db->prepare($query);
        $rows->execute();

        $count = $rows->rowCount();
        return $count ;
    }
}
