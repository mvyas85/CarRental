<?php
class Order {
    private $orderID,$customerID,$carID,$startDate,$endDate,$totalDays,$rateApplied,$amount,$tax,$total; 
    
    public function __construct($orderID,$customerID,$carID,$startDate,$endDate,$totalDays,$rateApplied,$amount,$tax,$total)
    {
        $this->orderID=$orderID;
        $this->customerID=$customerID;
        $this->carID=$carID;
        $this->startDate=$startDate;
        $this->endDate=$endDate;
        $this->totalDays=$totalDays;
        $this->rateApplied=$rateApplied;
        $this->amount=$amount;
        $this->tax=$tax;
        $this->total=$total;
    }
    
    public function getOrderID(){ return $this->orderID;}
    public function getcustomerID(){ return $this->customerID;}
    public function getCarID(){ return $this->carID;}
    public function getStartDate(){ return $this->startDate;}
    public function getEndDate(){ return $this->endDate;}
    public function getTotalDays(){ return $this->totalDays;}
    public function getRateApplied(){ return $this->rateApplied;}
    public function getAmount(){ return $this->amount;}
    public function getTax(){ return $this->tax;}
    public function getTotal(){ return $this->total;}
    
    
    public function setSOrderID($orderID)
    { 
        $this->orderID=$orderID;    
    }
    public function setCustomerID($customerID)
    {
        $this->customerID=$customerID;
    }
    public function setCarID($carID)
    { 
        $this->carID=$carID;    
    }
    public function setStartDate($startDate)
    { 
        $this->startDate=$startDate;
    }
    public function setEndDate($endDate)
    { 
        $this->endDate=$endDate;
    }
    public function setTotalDays($totalDays)
    { 
        $this->totalDays=$totalDays;
    }
    public function setRateApplied($rateApplied)
    { 
        $this->rateApplied=$rateApplied;
    }
    public function setAmount($amount)
    { 
        $this->amount=$amount;    
    }
    public function setTax($tax)
    { 
        $this->tax=$tax;    
    }
     public function setTotal($total)
    { 
        $this->total=$total;
    }
}