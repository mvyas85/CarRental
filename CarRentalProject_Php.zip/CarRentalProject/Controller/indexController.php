<?php
require('../Model/CustomerRepository.php');
require('../Model/OrderRepository.php');

    if(isset($_GET['cancel']))
    {
        $orderID=$_GET['cancel'];
        OrderRepository::deleteOrderByOrderID($orderID);
        
        $success = 'Order ID:'.$orderID.' Cancelled Sucessfully !'
                . '<br>Refund will be made to your account within 7 working days !'
                . '<br>Call on call center 123-456-7890 for any other detail.';
        header('Location:  ../View/home.php?messege='.$success);
        exit();
    }
    if(isset($_POST['confirm_booking']))
    {
        if(!session_id()) 
        {
           session_start();
           session_cache_expire (21900);
        }
         if(!isset($_SESSION['myusername']))
        {
            $errorMsg = 'Please Login to Make booking! ';
            header('Location: ../View/Login.php?error='.$errorMsg);
            exit();
         }
         
        $customer = CustomerRepository::getACustomerByFirstName($_SESSION['myusername']);;
        $customerID= $customer->getcustomerID();
        $carID = $_POST['carID'];
        $pickup_date = $_POST['pickup_date'];
        $pickup_hour = $_POST['pickup_hour'];
        $pickup_min = $_POST['pickup_min'];
        $startDate = $pickup_date.' '.$pickup_hour.':'.$pickup_min.':00';
        $return_date = $_POST['return_date'];
        $return_hour = $_POST['return_hour'];
        $return_min = $_POST['return_min'];
        $endDate = $return_date.' '.$return_hour.':'.$return_min.':00';
        $totalDays=$_POST['days'];
        $rateApplied=$_POST['rate'];
        $amount=$_POST['amount'];
        $tax=$_POST['tax'];
        $total=$_POST['total'];
        
        OrderRepository::createNewOrder($customerID, $carID, $startDate, $endDate, $totalDays, $rateApplied, $amount, $tax, $total);
        
        $success = 'Order Placed Sucessfully !';
        header('Location:  ../View/home.php?messege='.$success);
        exit();
                
     }
    //Edit Account information
    if(isset($_POST['edit_acc']))
    {
        if($_POST['newusername'] && $_POST['newpassword'] && $_POST['confirmnewpassword'] 
                && $_POST['newfirstName'] && $_POST['newlastName'] && $_POST['newdrivLicNum']
                && $_POST['newaddress'] && $_POST['newcity'] && $_POST['newstate'] && $_POST['newzipCode']) 
        {
            $newusername = $_POST['newusername'];
            $newpassword = $_POST['newpassword'] ;
            $confirmpassword = $_POST['confirmnewpassword'];
            $firstName = $_POST['newfirstName'];
            $lastName = $_POST['newlastName'] ;
            $drivLicNum= $_POST['newdrivLicNum'];
            $address = $_POST['newaddress'];
            $city = $_POST['newcity'];
            $state = $_POST['newstate'];
            $zipCode = $_POST['newzipCode'];
            
            if($newpassword != $confirmpassword)
            {
                $passwordDonotMatch = 'Password and Confirm Password Do not Match !';
                header('Location: ../View/editAccInfo.php?messege='.$passwordDonotMatch);
                exit();
            }
            else
            {
                $old_logged_customer = CustomerRepository::getACustomerByEmail($newusername);
                $_SESSION['myid'] = $old_logged_customer->getcustomerID();
                CustomerRepository::updateCustomer($_SESSION['myid'],$newusername,$newpassword,$firstName,$lastName,$drivLicNum,$address,$city,$state,$zipCode);
                
                $lifetime = 60 * 60 ;//1 hour in seconds
                $path = '/';
                $domain = 'localhost/CarRentalProject/';
                $secure = true;
                $httponly = false;
                session_set_cookie_params($lifetime, $path, $domain, $secure, $httponly);

                session_start();
                $logged_customer = CustomerRepository::getACustomerByEmail($newusername);
                $_SESSION['myusername'] = $logged_customer->getFirstName();
                $_SESSION['myCustID']=$logged_customer->getcustomerID();
                $_SESSION['mypassword'] = $newpassword;
                
                $_SESSION['myemail'] = $newusername;
                $_SESSION['mylastName'] = $logged_customer->getLastName();
                $_SESSION['mydrivLicNum'] = $logged_customer->getDrivLicNum();
                $_SESSION['myAddress'] = $logged_customer->getAddress();
                $_SESSION['myCity'] = $logged_customer->getCity();
                $_SESSION['myState'] = $logged_customer->getState();
                $_SESSION['myZipCode'] = $logged_customer->getZipCode();
                
                 $success = 'Account Updated Sucessfully !';
                header('Location:  ../View/editAccInfo.php?messege='.$success);
                exit();
            } 
        }
        else
        {
            $errorMsg = 'All the fields are required !';
            header('Location: ../View/editAccInfo.php?error='.$errorMsg);
            exit();
        }    
    }
    //Create A User Account
    if(isset($_POST['create_user']))
    {
        if($_POST['newusername'] && $_POST['newpassword'] && $_POST['confirmnewpassword'] 
                && $_POST['newfirstName'] && $_POST['newlastName'] && $_POST['newdrivLicNum']
                && $_POST['newaddress'] && $_POST['newcity'] && $_POST['newstate'] && $_POST['newzipCode']) 
        {
            $newusername = $_POST['newusername'];
            $newpassword = $_POST['newpassword'] ;
            $confirmpassword = $_POST['confirmnewpassword'];
            $firstName = $_POST['newfirstName'];
            $lastName = $_POST['newlastName'] ;
            $drivLicNum= $_POST['newdrivLicNum'];
            $address = $_POST['newaddress'];
            $city = $_POST['newcity'];
            $state = $_POST['newstate'];
            $zipCode = $_POST['newzipCode'];
            
            if($newpassword != $confirmpassword)
            {
                $passwordDonotMatch = 'Password and Confirm Password Do not Match !';
                header('Location: ../View/Login.php?error='.$passwordDonotMatch);
                exit();
            }
            else
            {
                CustomerRepository::createNewCustomer($newusername,$newpassword,$firstName,$lastName,$drivLicNum,$address,$city,$state,$zipCode);
                
                $lifetime = 60 * 60 ;//1 hour in seconds
                $path = '/';
                $domain = 'localhost/CarRentalProject/';
                $secure = true;
                $httponly = false;
                session_set_cookie_params($lifetime, $path, $domain, $secure, $httponly);

                session_start();
                $logged_customer = CustomerRepository::getACustomerByEmail($newusername);
                $_SESSION['myusername'] = $logged_customer->getFirstName();
                $_SESSION['mypassword'] = $mypassword;
                $_SESSION['myCustID']=$logged_customer->getcustomerID();
                
                $_SESSION['myemail'] = $myusername;
                $_SESSION['mylastName'] = $logged_customer->getLastName();
                $_SESSION['mydrivLicNum'] = $logged_customer->getDrivLicNum();
                $_SESSION['myAddress'] = $logged_customer->getAddress();
                $_SESSION['myCity'] = $logged_customer->getCity();
                $_SESSION['myState'] = $logged_customer->getState();
                $_SESSION['myZipCode'] = $logged_customer->getZipCode();
                
                echo $_SESSION['myusername'];

                $success = 'Account Created Sucessfully !'
                        . '<br>Need to call on our call center number 123-456-7890 to provide us with your Credit Card Number'
                        . 'before you can make any online car rental bookings!';
                header('Location:  ../View/home.php?messege='.$success);
                exit();
            } 
        }
        else
        {
            $errorMsg = 'All the fields are required !';
            header('Location: ../View/Login.php?error='.$errorMsg);
            exit();
        }
    }

    //Loging in 
    if(isset($_POST['loggingin']))
    {
        if(isset($_POST['myusername'])  && isset($_POST['mypassword']))
        {
            $myusername=$_POST['myusername']; 
            $mypassword=$_POST['mypassword']; 

            // To protect MySQL injection 
            $myusername = stripslashes($myusername);
            $mypassword = stripslashes($mypassword);
            $myusername = mysql_real_escape_string($myusername);
            $mypassword = mysql_real_escape_string($mypassword);

            $count = CustomerRepository::confirmLogIn($myusername, $mypassword);
            
            // If result matched $myusername and $mypassword, table row must be 1 row
            if($count==1)
            {
                $lifetime = 60 * 60 ;//1 hour in seconds
                $path = '/';
                $domain = 'localhost/CarRentalProject/';
                $secure = true;
                $httponly = false;
                session_set_cookie_params($lifetime, $path, $domain, $secure, $httponly);

                session_start();
                $logged_customer = CustomerRepository::getACustomerByEmail($myusername);
                $_SESSION['myusername'] = $logged_customer->getFirstName();
                $_SESSION['mypassword'] = $mypassword;
                $_SESSION['myCustID']=$logged_customer->getcustomerID();
                
                $_SESSION['myemail'] = $myusername;
                $_SESSION['mylastName'] = $logged_customer->getLastName();
                $_SESSION['mydrivLicNum'] = $logged_customer->getDrivLicNum();
                $_SESSION['myAddress'] = $logged_customer->getAddress();
                $_SESSION['myCity'] = $logged_customer->getCity();
                $_SESSION['myState'] = $logged_customer->getState();
                $_SESSION['myZipCode'] = $logged_customer->getZipCode();
                header('Location: ../View/home.php');
                exit();
                
            }
            else
            {
                $loginerror="Invalid Username or Password!";
                header('Location: ../View/login.php?error='.$loginerror);
                exit();
            }
        }
    }
    
   
    //Logout
    if(isset($_GET['logout']))
    {
        session_start();
        session_destroy();
        header("Location:../View/home.php");
        exit();
    }

    //delete My Account
    if(isset($_GET['del']))
    {
        CustomerRepository::deleteCustomer($_GET['del']);
        session_start();
        session_destroy();
        header('Location:../View/home.php');
        exit();
    }
header('Location:../View/home.php');